import { getApps, initializeApp, cert, type App } from "firebase-admin/app";
import { getAuth, type DecodedIdToken } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import { isAdminEmail } from "./adminConfig";

function rebuildPemFromBody(header: string, footer: string, rawBody: string): string {
  const base64Only = rawBody
    .replace(/\\n/g, "")
    .replace(/\\r/g, "")
    .replace(/[^A-Za-z0-9+/=]/g, "");
  const lines = base64Only.match(/.{1,64}/g) || [];
  return `${header}\n${lines.join("\n")}\n${footer}\n`;
}

function normalizePrivateKey(raw: string | undefined): string | undefined {
  if (!raw) return undefined;
  let cleaned = raw.trim();

  if (cleaned.startsWith("{")) {
    try {
      const parsed = JSON.parse(cleaned) as { private_key?: string };
      if (parsed.private_key) cleaned = parsed.private_key;
    } catch {
      // fall through
    }
  }

  cleaned = cleaned.replace(/^"?private_key"?\s*:\s*/i, "").replace(/,\s*$/, "").trim();
  cleaned = cleaned.replace(/^["'“”‘’]+|["'“”‘’]+$/g, "").trim();

  if (!cleaned.includes("BEGIN") && /^[A-Za-z0-9+/=\s]+$/.test(cleaned) && cleaned.length > 200) {
    try {
      const decoded = Buffer.from(cleaned.replace(/\s+/g, ""), "base64").toString("utf-8");
      if (decoded.includes("BEGIN")) {
        cleaned = decoded;
      }
    } catch {
      // fall through
    }
  }

  cleaned = cleaned.replace(/\\\\n/g, "\n").replace(/\\n/g, "\n").replace(/\\r/g, "");

  const pkcs8Match = cleaned.match(/-----BEGIN PRIVATE KEY-----([\s\S]*?)-----END PRIVATE KEY-----/);
  if (pkcs8Match) {
    return rebuildPemFromBody(
      "-----BEGIN PRIVATE KEY-----",
      "-----END PRIVATE KEY-----",
      pkcs8Match[1]
    );
  }

  const rsaMatch = cleaned.match(/-----BEGIN RSA PRIVATE KEY-----([\s\S]*?)-----END RSA PRIVATE KEY-----/);
  if (rsaMatch) {
    return rebuildPemFromBody(
      "-----BEGIN RSA PRIVATE KEY-----",
      "-----END RSA PRIVATE KEY-----",
      rsaMatch[1]
    );
  }

  return cleaned;
}

function ensureAdminApp(): App {
  const existingApps = getApps();
  if (existingApps.length > 0) {
    return existingApps[0];
  }

  let projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID?.trim();
  let clientEmail = process.env.FIREBASE_CLIENT_EMAIL?.trim();
  let rawKey = process.env.FIREBASE_PRIVATE_KEY;

  const jsonEnv = process.env.FIREBASE_SERVICE_ACCOUNT_JSON?.trim();
  if (jsonEnv && jsonEnv.startsWith("{")) {
    try {
      const sa = JSON.parse(jsonEnv) as {
        project_id?: string;
        client_email?: string;
        private_key?: string;
      };
      projectId = projectId || sa.project_id?.trim();
      clientEmail = clientEmail || sa.client_email?.trim();
      rawKey = rawKey || sa.private_key;
    } catch {
      // ignore invalid JSON
    }
  }

  const privateKey = normalizePrivateKey(rawKey);

  if (!projectId || !clientEmail || !privateKey) {
    throw new Error(
      "Firebase Admin env vars missing (NEXT_PUBLIC_FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY)."
    );
  }

  if (!privateKey.includes("-----BEGIN") || privateKey.length < 400) {
    throw new Error(
      `FIREBASE_PRIVATE_KEY is invalid (length=${privateKey.length}). Copy the long "private_key" value (not "private_key_id") from your Firebase Service Account JSON.`
    );
  }

  return initializeApp({
    credential: cert({
      projectId,
      clientEmail,
      privateKey,
    }),
  });
}

export function getAdminAuth() {
  return getAuth(ensureAdminApp());
}

export function getAdminDb() {
  return getFirestore(ensureAdminApp());
}

export interface AdminAuthResult {
  user: DecodedIdToken | null;
  error?: string;
  status: number;
}

export async function authenticateAdminRequest(req: Request): Promise<AdminAuthResult> {
  const token = req.headers.get("authorization")?.split("Bearer ")[1];
  if (!token) {
    return { user: null, error: "Missing sign-in token. Please sign in again.", status: 401 };
  }

  try {
    const decoded = await getAdminAuth().verifyIdToken(token);
    if (decoded.email_verified && isAdminEmail(decoded.email)) {
      return { user: decoded, status: 200 };
    }
    return {
      user: null,
      error: `Admin access required (${decoded.email || "unknown account"} is not an admin).`,
      status: 403,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown Firebase Admin error";
    console.error("authenticateAdminRequest failed:", err);
    return {
      user: null,
      error: `Server auth check failed: ${msg}`,
      status: 500,
    };
  }
}

export async function verifyAdminRequest(req: Request): Promise<DecodedIdToken | null> {
  const result = await authenticateAdminRequest(req);
  return result.user;
}
